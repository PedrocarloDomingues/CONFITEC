USE [ImportacaoVerba]
GO

/****** Object:  Table [dbo].[LancamentoVerba]    Script Date: 12/13/2020 6:17:20 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[LancamentoVerba](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[FuncionarioId] [int] NOT NULL,
	[VerbaId] [int] NOT NULL,
	[Quantidade] [decimal](18, 2) NOT NULL,
	[Valor] [decimal](18, 2) NOT NULL,
	[MesAnoInicio] [char](7) NOT NULL,
	[MesAnoFim] [char](7) NOT NULL,
 CONSTRAINT [PK_LancamentoVerba] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

