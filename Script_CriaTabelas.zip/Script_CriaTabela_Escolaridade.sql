USE [CRUDUsuario]
GO

/****** Object:  Table [dbo].[Escolaridade]    Script Date: 12/14/2020 4:40:20 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Escolaridade](
	[IdEscolaridade] [int] NOT NULL,
	[DescricaoEscolaridade] [varchar](50) NULL,
 CONSTRAINT [PK_Escolaridade] PRIMARY KEY CLUSTERED 
(
	[IdEscolaridade] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


