import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Usuario } from './usuario';


@Injectable({
  providedIn: 'root'
})
  
export class UsuarioService {
  url = 'http://localhost:65389/Api/Usuarios';
  constructor(private http: HttpClient) { }

  getAllUsuario(): Observable<Usuario[]> {
    return this.http.get<Usuario[]>(this.url + '/AllUsuarioDetails');
  }

  getUsuarioById(usuarioId: string): Observable<Usuario> {
    return this.http.get<Usuario>(this.url + '/GetUsuarioDetailsById/' + usuarioId);
  }

  createUsuario(usuario: Usuario): Observable<Usuario> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post<Usuario>(this.url + '/InsertUsuarioDetails/',
      usuario, httpOptions);
  }

  updateUsuario(usuario: Usuario): Observable<Usuario> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.put<Usuario>(this.url + '/UpdateUsuarioDetails/',
      usuario, httpOptions);
  }

  deleteUsuarioById(usuarioid: string): Observable<number> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.delete<number>(this.url + '/DeleteUsuarioDetails?id=' + usuarioid,
      httpOptions);
  }
}  
