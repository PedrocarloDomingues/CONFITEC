export class Usuario {
  Id: number;
  Nome: string;
  Sobrenome: string;
  Email: string;
  DataNascimento: Date;
  IdEscolaridade: number;
}
