import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { UsuarioService } from '../usuario.service';
import { Usuario } from '../usuario';

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.component.html',
  styleUrls: ['./usuario.component.css']
})



export class UsuarioComponent implements OnInit {
  dataSaved = false;
  usuarioForm: any;
  allUsuarios: Observable<Usuario[]>;
  usuariodUpdate = null;
  message = null;

  constructor(private formbulider: FormBuilder, private usuarioService: UsuarioService) { }

  ngOnInit() {
    this.usuarioForm = this.formbulider.group({
      Nome: ['', [Validators.required]],
      Sobrenome: ['', [Validators.required]],
      DataNascimento: ['', [Validators.required]],
      Email: ['', [Validators.required]],
      Escolaridade: ['', [Validators.required]],
    });
    this.loadAllUsuarios();
  }

  loadAllUsuarios() {
    this.allUsuarios = this.usuarioService.getAllUsuario();
  }

  onFormSubmit() {
    this.dataSaved = false;
    const usuario = this.usuarioForm.value;
    this.CreateUsuario(usuario);
    this.usuarioForm.reset();
  }

  loadUsuarioToEdit(usuarioId: string) {
    this.usuarioService.getUsuarioById(usuarioId).subscribe(usuario => {
      this.message = null;
      this.dataSaved = false;
      this.usuariodUpdate = usuario.Id;
      this.usuarioForm.controls['Nome'].setValue(usuario.Nome);
      this.usuarioForm.controls['Sobrenome'].setValue(usuario.Sobrenome);
      this.usuarioForm.controls['DataNascimento'].setValue(usuario.DataNascimento);
      this.usuarioForm.controls['Email'].setValue(usuario.Email);
      this.usuarioForm.controls['Escolaridade'].setValue(usuario.IdEscolaridade);
      
    });

  }


  CreateUsuario(usuario: Usuario) {
  
    if (this.usuariodUpdate == null) {
      this.usuarioService.createUsuario(usuario).subscribe(
        () => {
          this.dataSaved = true;
          this.message = 'Registro Salvo com sucesso.';
          this.loadAllUsuarios();
          this.usuariodUpdate = null;
          this.usuarioForm.reset();
        }
      );
    } else {
      usuario.Id = this.usuariodUpdate;
      this.usuarioService.updateUsuario(usuario).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Registro Atualizado com sucesso.';
        this.loadAllUsuarios();
        this.usuariodUpdate = null;
        this.usuarioForm.reset();
      });
    }
  }


  deleteUsuario(usuarioId: string) {
    if (confirm("Você deseja  realmente excluir este  registro ?")) {
      this.usuarioService.deleteUsuarioById(usuarioId).subscribe(() => {
        this.dataSaved = true;
        this.message = 'Registro deletado com sucesso';
        this.loadAllUsuarios();
        this.usuariodUpdate = null;
        this.usuarioForm.reset();

      });
    }
  }
  resetForm() {
    this.usuarioForm.reset();
    this.message = null;
    this.dataSaved = false;
  }
}
