export class Usuario {
  Id: number;
  DescricaoEscolaridade: string;
}
