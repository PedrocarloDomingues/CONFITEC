﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EFCore.Angular.CRUDUsuario.Models
{
    public partial class Escolaridade
    {
        public Escolaridade()
        {
            Usuarios = new HashSet<Usuario>();
        }

        public int IdEscolaridade { get; set; }
        public string DescricaoEscolaridade { get; set; }

        public virtual ICollection<Usuario> Usuarios { get; set; }
    }
}
