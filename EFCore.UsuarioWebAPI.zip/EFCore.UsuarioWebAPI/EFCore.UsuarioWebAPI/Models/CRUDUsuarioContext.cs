﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace EFCore.Angular.CRUDUsuario.Models
{
    public partial class CRUDUsuarioContext : DbContext
    {
        public CRUDUsuarioContext()
        {
        }

        public CRUDUsuarioContext(DbContextOptions<CRUDUsuarioContext> options)
            : base(options)
        {
        }

       
        public virtual DbSet<Escolaridade> Escolaridades { get; set; }
        public virtual DbSet<Usuario> Usuarios { get; set; }

        //        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //        {
        //            if (!optionsBuilder.IsConfigured)
        //            {
        //#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        //                optionsBuilder.UseSqlServer("Data Source=PEDROCARLOM12D1\\SQLEXPRESS;Initial Catalog=CRUDUsuario;Integrated Security=True");
        //            }
        //        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

           
            modelBuilder.Entity<Escolaridade>(entity =>
            {
                entity.HasKey(e => e.IdEscolaridade);

                entity.ToTable("Escolaridade");

                entity.Property(e => e.IdEscolaridade).ValueGeneratedNever();

                entity.Property(e => e.DescricaoEscolaridade)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Usuario>(entity =>
            {
                entity.ToTable("Usuario");

                entity.Property(e => e.DataNascimento).HasColumnType("date");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Sobrenome)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdEscolaridadeNavigation)
                    .WithMany(p => p.Usuarios)
                    .HasForeignKey(d => d.IdEscolaridade)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Usuario_Escolaridade");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
